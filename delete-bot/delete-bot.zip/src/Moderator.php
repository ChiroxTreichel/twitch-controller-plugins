<?php

declare(strict_types=1);

namespace TwitchController\Plugin\DeleteBot;

use TwitchController\Core\App;

/**
 * Der Betrieb: jede Chatnachricht pruefen und bei Treffer loeschen.
 *
 * Laeuft im Webhook-Request (core.chat.message). Twitch wartet auf
 * unsere Antwort, und geloescht werden soll schnell - eine Nachricht,
 * die erst nach zehn Sekunden verschwindet, hat jeder gelesen.
 */
final class Moderator
{
    public function __construct(private readonly App $app)
    {
    }

    /**
     * @param array<string, mixed> $message Nutzlast von core.chat.message
     */
    public function handle(array $message): void
    {
        if (!Words::enabled($this->app)) {
            return;
        }

        $text = (string) ($message['text'] ?? '');
        if (trim($text) === '') {
            return;
        }

        // active(): die leeren Platzhalterzeilen aus der Oberflaeche
        // gehoeren nicht in die Pruefung.
        $muster = Words::active($this->app);
        if ($muster === []) {
            return;
        }

        $ergebnis = Words::check($text, $muster);

        // Kaputte Muster fallen hier auf, nicht erst wenn jemand sich
        // wundert. Einmal je Nachricht ist zu oft - gemeldet wird nur,
        // wenn ohnehin etwas passiert.
        if (!$ergebnis['blocked']) {
            return;
        }

        // Ausnahmen erst jetzt: "folgt seit" ist eine Anfrage bei
        // Twitch, und die soll nur fuer die Nachrichten anfallen, die
        // sonst fallen wuerden - nicht fuer jede Zeile im Chat.
        $ausnahme = Exemptions::reason($this->app, $message);
        if ($ausnahme !== null) {
            $this->app->log(sprintf(
                'Loeschbot: Treffer bei %s (Muster: %s), aber ausgenommen (%s).',
                (string) ($message['chatter_login'] ?? '?'),
                $ergebnis['pattern'],
                $ausnahme
            ));

            return;
        }

        $messageId = (string) ($message['message_id'] ?? '');
        if ($messageId === '') {
            $this->app->log('Loeschbot: Treffer, aber ohne Nachrichten-Nummer.');

            return;
        }

        $geloescht = $this->app->chat->delete($messageId);

        if ($geloescht['ok']) {
            $this->app->log(sprintf(
                'Loeschbot: Nachricht von %s geloescht (Muster: %s).',
                (string) ($message['chatter_login'] ?? '?'),
                $ergebnis['pattern']
            ));

            $this->app->hooks->dispatch('delete_bot.deleted', $message, $ergebnis['pattern']);

            return;
        }

        // Der haeufigste Fall hier ist der Kanalinhaber selbst: seine
        // eigenen Nachrichten laesst Twitch niemanden loeschen. Das ist
        // kein Fehler der Einstellung, deshalb steht die Ursache im
        // Log und nicht nur ein "fehlgeschlagen".
        $this->app->log(sprintf(
            'Loeschbot: Treffer bei %s (Muster: %s), aber nicht geloescht: %s',
            (string) ($message['chatter_login'] ?? '?'),
            $ergebnis['pattern'],
            $geloescht['error']
        ));
    }
}
