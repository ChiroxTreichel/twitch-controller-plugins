<?php

declare(strict_types=1);

namespace TwitchController\Plugin\Subathon;

use TwitchController\Core\App;

/**
 * ===================================================================
 *  Subathon - die Zeit und was sie verlaengert
 * ===================================================================
 *
 * Uebernommen aus dem Windows-Programm (legacy/subathon-tool): ein
 * Stream, der laenger wird, wenn jemand abonniert, Bits schickt oder
 * spendet - bis zu einer Obergrenze.
 *
 * Der wichtigste Unterschied zum Original ist, dass hier NICHTS im
 * Sekundentakt laeuft.
 *
 * Dort zaehlte ein Timer jede Sekunde hoch und schrieb die Pausenzeit
 * in die config.json - eine Datei, jede Sekunde, damit ein Wert
 * stimmt, den man auch ausrechnen kann. Hier stehen drei Zahlen in den
 * Einstellungen (Start, Dauer, Pause), und woraus sich alles andere
 * ergibt, ergibt sich daraus:
 *
 *     Ende = Start + Dauer + Pause
 *
 * Die laufende Anzeige rechnet der Browser, und der kann das.
 */
final class Subathon
{
    public const SLUG = 'subathon';

    /** Vorgaben wie im Programm (config.cs). */
    public const DEFAULT_TIMER = 28800;         // 8 Stunden
    public const DEFAULT_MAX = 172800;          // 48 Stunden
    public const DEFAULT_SECONDS_PER_SUB = 3600;
    public const DEFAULT_BITS_PER_SUB = 300;
    public const DEFAULT_CENT_PER_SUB = 300;

    /**
     * Die Preise der Abostufen in Euro.
     *
     * Vorgabe ist, was im Programm fest im Code stand - 4,99 / 7,99 /
     * 19,99. Twitch verlangt aber nicht ueberall dasselbe und aendert
     * seine Preise; darum stehen sie in den Einstellungen des Plugins.
     *
     * Gebraucht wird daraus nur das VERHAELTNIS: ein Abo der Stufe 1
     * bringt die eingestellten Minuten, die anderen entsprechend ihrem
     * Preis. Wer alle drei verdoppelt, aendert also nichts.
     */
    public const TIER_PRICE = ['1000' => 4.99, '2000' => 7.99, '3000' => 19.99];

    /**
     * Die eingetragenen Preise, mit der Vorgabe als Rueckfall.
     *
     * @return array<string, float>
     */
    public static function tierPrices(App $app): array
    {
        $preise = [];

        foreach (self::TIER_PRICE as $stufe => $vorgabe) {
            $preise[$stufe] = self::price(
                (float) $app->settings->string('price_tier' . $stufe, '', self::scope()),
                $vorgabe
            );
        }

        return $preise;
    }

    /**
     * Ein Preis, der sich rechnen laesst.
     *
     * 0 oder weniger waere eine Division durch Null bei Stufe 1 - und
     * bei den anderen ein Abo, das nichts bringt. In beiden Faellen
     * ist die Vorgabe die bessere Antwort als ein Fehler.
     */
    public static function price(float $wert, float $vorgabe): float
    {
        if ($wert <= 0 || $wert > 9999) {
            return $vorgabe;
        }

        return round($wert, 2);
    }

    public static function scope(): string
    {
        return 'plugin:' . self::SLUG;
    }

    // -----------------------------------------------------------------
    //  Die Einstellungen
    // -----------------------------------------------------------------

    public static function timer(App $app): int
    {
        return max(0, $app->settings->int('timer', self::DEFAULT_TIMER, self::scope()));
    }

    public static function maxDuration(App $app): int
    {
        return max(0, $app->settings->int('max_duration', self::DEFAULT_MAX, self::scope()));
    }

    /** Der Startzeitpunkt als Unixzeit - 0 heisst "noch keiner". */
    public static function start(App $app): int
    {
        return max(0, $app->settings->int('start', 0, self::scope()));
    }

    /** Gesammelte Pausenzeit in Sekunden. */
    public static function breakTime(App $app): int
    {
        return max(0, $app->settings->int('break_time', 0, self::scope()));
    }

    public static function isPaused(App $app): bool
    {
        return $app->settings->bool('pause', false, self::scope());
    }

    /** Seit wann pausiert wird - 0 heisst "wird nicht pausiert". */
    public static function pausedAt(App $app): int
    {
        return max(0, $app->settings->int('paused_at', 0, self::scope()));
    }

    public static function owner(App $app): string
    {
        return $app->settings->string('owner', '', self::scope());
    }

    public static function secondsPerSub(App $app): int
    {
        return max(1, $app->settings->int('seconds_per_sub', self::DEFAULT_SECONDS_PER_SUB, self::scope()));
    }

    public static function bitsPerSub(App $app): int
    {
        return max(1, $app->settings->int('bits_per_sub', self::DEFAULT_BITS_PER_SUB, self::scope()));
    }

    public static function centPerSub(App $app): int
    {
        return max(1, $app->settings->int('cent_per_sub', self::DEFAULT_CENT_PER_SUB, self::scope()));
    }

    // -----------------------------------------------------------------
    //  Multiplikatoren
    // -----------------------------------------------------------------

    /**
     * Woher eine Spende kommen kann, die einen eigenen Multiplikator hat.
     *
     * StreamElements und StreamLabs fehlen mit Absicht: sie melden in
     * 'tips.donation' keinen Anbieter mit, und ein Multiplikator, der
     * nicht weiss, worauf er wirkt, waere geraten.
     */
    public const MULTIPLIER_SOURCES = ['paypal', 'throne'];

    /** Mehr als zehnfach ist ein Tippfehler, keine Aktion. */
    public const MULTIPLIER_MAX = 10.0;

    /** In Zehnteln - feiner unterscheidet im Stream niemand. */
    public const MULTIPLIER_STEP = 0.1;

    /** Der Text, der statt der Zahl in der Laufschrift steht. */
    public const MULTIPLIER_TEXT_MAX = 100;

    /**
     * Wie viel eine Spende ueber diesen Weg mehr zaehlt.
     *
     * 1 heisst: wie jede andere Spende. 0 heisst: zaehlt gar nicht -
     * auch das darf man wollen.
     */
    public static function multiplier(App $app, string $quelle): float
    {
        $wert = $app->settings->get('multi_' . $quelle, 1.0, self::scope());

        return is_numeric($wert) ? max(0.0, min(self::MULTIPLIER_MAX, round((float) $wert, 1))) : 1.0;
    }

    /** Der eigene Text zum Multiplikator - leer, wenn keiner da ist. */
    public static function multiplierText(App $app, string $quelle): string
    {
        return $app->settings->string('multi_' . $quelle . '_text', '', self::scope());
    }

    /**
     * Was {{ multi_paypal }} und {{ multi_throne }} einsetzen.
     *
     * Der eigene Text, wenn einer da ist - "doppelt" liest sich in der
     * Laufschrift besser als "2". Sonst die Zahl, ohne Nachkommastelle,
     * wo keine noetig ist.
     */
    public static function multiplierLabel(App $app, string $quelle): string
    {
        $text = self::multiplierText($app, $quelle);

        return $text !== '' ? $text : Texts::number(self::multiplier($app, $quelle));
    }

    /**
     * Ein Multiplikator aus dem Formular - "1,5" wie "1.5".
     *
     * Null heisst: nicht lesbar. Leer ist nicht lesbar und nicht 0 -
     * ein Feld, das man aus Versehen leert, soll keine Spenden
     * abschalten. Gerundet auf Zehntel, wie das Feld zaehlt.
     */
    public static function parseMultiplier(string $eingabe): ?float
    {
        $eingabe = str_replace(',', '.', trim($eingabe));

        if ($eingabe === '' || !is_numeric($eingabe)) {
            return null;
        }

        $wert = round((float) $eingabe, 1);

        return $wert < 0 || $wert > self::MULTIPLIER_MAX ? null : $wert;
    }

    /**
     * Soll der Reiter "Manuelles Buchen" da sein?
     *
     * Aus, solange niemand ihn anschaltet. Abos, Bits und Spenden
     * buchen sich von selbst; von Hand braucht man ihn nur, wenn
     * etwas auf einem Weg ankommt, den dieses System nicht sieht -
     * eine Ueberweisung, ein Geschenk im Chat.
     *
     * Ein Reiter, den man nie braucht, ist auch einer, in den man
     * sich vertippt: fuenf Knoepfe, die Zeit verschenken, direkt
     * neben den Einstellungen.
     */
    public static function showManual(App $app): bool
    {
        return $app->settings->bool('show_manual', false, self::scope());
    }

    /**
     * Die Nachrichten der Laufschrift, eine je Zeile.
     *
     * @return list<string>
     */
    public static function messages(App $app): array
    {
        $roh = json_decode($app->settings->string('messages', '[]', self::scope()), true);

        if (!is_array($roh)) {
            return [];
        }

        return array_values(array_map(static fn (mixed $zeile): string => (string) $zeile, $roh));
    }

    /** @param list<string> $zeilen */
    public static function setMessages(App $app, array $zeilen): void
    {
        $app->settings->set('messages', json_encode(array_values($zeilen), JSON_UNESCAPED_UNICODE), self::scope());
    }

    // -----------------------------------------------------------------
    //  Die Farben des Overlays
    // -----------------------------------------------------------------

    /**
     * Sechs Farben, wie im Programm (config.RowNames): Hintergrund und
     * Schrift je Abschnitt.
     *
     * Die Vorgaben sind die von dort - lightgreen, #f79191, skyblue -
     * und nicht die des Systems: das Overlay liegt ueber dem Spiel und
     * hat mit der Verwaltung nichts zu tun.
     */
    public const COLORS = [
        'done'          => 'lightgreen',
        'done_text'     => 'Black',
        'todo'          => '#f79191',
        'todo_text'     => 'Black',
        'possible'      => 'skyblue',
        'possible_text' => 'Black',
    ];

    /** @return array<string, string> */
    public static function colors(App $app): array
    {
        $farben = [];

        foreach (self::COLORS as $name => $vorgabe) {
            $farben[$name] = self::normalizeColor(
                $app->settings->string('color_' . $name, '', self::scope()),
                $vorgabe
            );
        }

        return $farben;
    }

    /**
     * Eine Farbangabe, die im Stylesheet nichts anrichten kann.
     *
     * Sie landet in einem style-Attribut. Ein Semikolon oder eine
     * Klammer darin waere eine zweite Angabe - darum nur, was wie eine
     * Farbe aussieht: #abc, #aabbcc oder ein Name aus Buchstaben.
     */
    public static function normalizeColor(string $wert, string $vorgabe): string
    {
        $wert = trim($wert);

        if (preg_match('/^#[0-9a-fA-F]{3}$|^#[0-9a-fA-F]{6}$|^[a-zA-Z]{3,24}$/', $wert) === 1) {
            return $wert;
        }

        return $vorgabe;
    }

    // -----------------------------------------------------------------
    //  Die Zeit
    // -----------------------------------------------------------------

    /**
     * Die Pausenzeit einschliesslich der laufenden Pause.
     *
     * Das Programm zaehlte sie jede Sekunde hoch und schrieb sie
     * weg. Hier steht der Anfang der Pause, und der Rest ist eine
     * Subtraktion - dieselbe Zahl, ohne eine Schreiboperation je
     * Sekunde.
     */
    public static function effectiveBreak(int $break, bool $pause, int $pausedAt, int $jetzt): int
    {
        if (!$pause || $pausedAt <= 0) {
            return max(0, $break);
        }

        return max(0, $break) + max(0, $jetzt - $pausedAt);
    }

    /** Wann Schluss ist: Start + Dauer + Pause. */
    public static function endAt(int $start, int $timer, int $break): int
    {
        return $start + $timer + $break;
    }

    /**
     * Der Zustand, wie ihn die Uebersicht und das Overlay brauchen.
     *
     * Vier Faelle, genau wie im Programm (Form1.Tick):
     *
     *   idle     kein Start eingetragen, oder er liegt noch vor uns
     *   running  laeuft
     *   paused   pausiert
     *   ended    die Zeit ist abgelaufen
     */
    public static function statusOf(int $start, int $ende, bool $pause, int $jetzt): string
    {
        if ($start <= 0) {
            return 'idle';
        }

        if ($jetzt > $ende) {
            return 'ended';
        }

        if ($pause) {
            return 'paused';
        }

        return $jetzt < $start ? 'idle' : 'running';
    }

    /**
     * Laeuft das Plugin ueberhaupt?
     *
     * Aus heisst: nichts wird gebucht, nichts gemeldet, nichts
     * angezeigt. Die Seite bleibt bedienbar - man soll nachsehen und
     * einstellen koennen, ohne dass dabei etwas zaehlt.
     *
     * Das ist NICHT "Pausieren". Pausieren haelt die Uhr an und holt
     * die Zeit hinterher wieder auf; der Hauptschalter tut das nicht.
     * Wer ihn mitten im Lauf umlegt, verliert die Abos und Spenden
     * dieser Zeit - sie kommen an, werden aber nicht gutgeschrieben.
     */
    public static function enabled(App $app): bool
    {
        return $app->settings->bool('enabled', true, self::scope());
    }

    public static function setEnabled(App $app, bool $an): void
    {
        $app->settings->set('enabled', $an, self::scope());
    }

    /**
     * Sind die Einstellungen zu?
     *
     * Sobald er laeuft - und pausiert ist gelaufen. Wer die Startzeit
     * mitten im Lauf verschiebt, verschiebt das Ende, nachdem alle es
     * gesehen haben; wer "Minuten pro Sub" aendert, sorgt dafuer, dass
     * zwei Abos derselben Stunde verschieden viel gebracht haben,
     * ohne dass es irgendwo steht.
     *
     * Vorher und nachher geht es: davor ist noch nichts passiert,
     * danach ist alles vorbei.
     */
    public static function isLocked(string $status): bool
    {
        return $status === 'running' || $status === 'paused';
    }

    /**
     * Die drei Balken des Overlays - 1:1 aus OverlayServer.ServeCalc.
     *
     *   done      wie lange schon gestreamt wird (ohne Pausen)
     *   todo      wie lange noch
     *   possible  wie viel sich noch dazukaufen laesst
     *   total     die Obergrenze; -1 heisst "keine"
     *
     * Vor dem Start gibt es nichts anzuzeigen: dort steht im Original
     * "[]", und das Overlay blendet sich aus.
     *
     * @return array{done: int, todo: int, possible: int, total: int}|null
     */
    public static function calc(int $start, int $timer, int $max, int $break, int $jetzt): ?array
    {
        if ($start <= 0 || $jetzt < $start) {
            return null;
        }

        $ende = self::endAt($start, $timer, $break);

        $done = $jetzt - $start - $break;
        $todo = $ende - $jetzt;

        if ($max <= 0) {
            return ['done' => $done, 'todo' => $todo, 'possible' => -1, 'total' => -1];
        }

        $maxEnde = $start + $max + $break;

        return [
            'done'     => $done,
            'todo'     => $todo,
            'possible' => $maxEnde - $ende,
            'total'    => $max,
        ];
    }

    // -----------------------------------------------------------------
    //  Was Zeit bringt
    // -----------------------------------------------------------------

    /**
     * Sekunden fuer ein Abo einer Stufe.
     *
     * Stufe 2 und 3 kosten mehr und bringen entsprechend mehr - die
     * Rechnung ist die des Programms, nur ohne die Kommastelle: dort
     * wurde auf int geschnitten, hier auch.
     */
    /**
     * @param array<string, float> $preise die drei Stufenpreise
     */
    public static function secondsForSub(int $secondsPerSub, string $tier, array $preise = self::TIER_PRICE): int
    {
        /*
         * Erst aufraeumen, dann rechnen. Eine 0 in der Liste waere
         * sonst zweierlei Aerger: als Teiler eine Division durch
         * Null, als Preis ein Abo, das nichts bringt.
         */
        $sauber = [];

        foreach (self::TIER_PRICE as $stufe => $vorgabe) {
            $sauber[$stufe] = self::price((float) ($preise[$stufe] ?? 0), $vorgabe);
        }

        // Eine Stufe, die es nicht gibt, zaehlt wie die erste - so
        // machte es der Standardfall im switch des Programms.
        $preis = $sauber[$tier] ?? $sauber['1000'];

        return (int) (($secondsPerSub / $sauber['1000']) * $preis);
    }

    public static function secondsForBits(int $secondsPerSub, int $bitsPerSub, int $bits): int
    {
        return (int) ($bits * ($secondsPerSub / max(1, $bitsPerSub)));
    }

    /** Spenden rechnen in CENT - so wie das Programm es tut. */
    public static function secondsForCents(int $secondsPerSub, int $centPerSub, int $cents): int
    {
        return (int) ($cents * ($secondsPerSub / max(1, $centPerSub)));
    }

    /**
     * Die neue Dauer nach einer Gutschrift, auf die Obergrenze
     * gedeckelt.
     *
     * Eine Obergrenze von 0 heisst "keine" - dann laeuft es weiter.
     */
    public static function capped(int $timer, int $plus, int $max): int
    {
        $neu = $timer + $plus;

        if ($max > 0 && $neu > $max) {
            return $max;
        }

        return $neu;
    }
}
